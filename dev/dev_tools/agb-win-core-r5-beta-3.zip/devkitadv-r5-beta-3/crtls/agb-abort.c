void abort (void)
{
  for(;;);
}



