
//{{BLOCK(verdana11)

#ifndef __VERDANA11__
#define __VERDANA11__

extern const TFont verdana11Font;

#define verdana11GlyphsLen 3072
extern const unsigned int verdana11Glyphs[768];

#define verdana11WidthsLen 96
extern const unsigned char verdana11Widths[96];

#endif // __VERDANA11__

//}}BLOCK(verdana11)
