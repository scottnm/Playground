
//{{BLOCK(yesh1)

#ifndef __YESH1__
#define __YESH1__

// 4x8 Sub-pixel font by JanoS, http://www.haluz.org/yesh/

extern const TFont yesh1Font;

#define yesh1GlyphsLen 6144
extern const unsigned int yesh1Glyphs[1536];

#endif // __YESH1__

//}}BLOCK(yesh1)
