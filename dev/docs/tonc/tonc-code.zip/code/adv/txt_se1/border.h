//======================================================================
//
//	border, 24x48@4, 
//	+ palette 16 entries, not compressed
//	+ 18 tiles not compressed
//	Total size: 32 + 576 = 608
//
//	Time-stamp: 2005-12-07, 19:34:09
//	Exported by Cearn's Usenti v1.7.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//
//======================================================================

#ifndef __BORDER__
#define __BORDER__

#define borderPalLen 32
extern const unsigned int borderPal[8];

#define borderTilesLen 576
extern const unsigned int borderTiles[144];

#endif // __BORDER__

