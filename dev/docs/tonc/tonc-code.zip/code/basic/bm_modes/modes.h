//======================================================================
//
//	modes, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2005-12-24, 18:13:22
//	Exported by Cearn's Usenti v1.7.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//
//======================================================================

#ifndef __MODES__
#define __MODES__

#define modesBitmapLen 76800
extern const unsigned int modesBitmap[19200];

#define modesPalLen 32
extern const unsigned int modesPal[8];

#endif // __MODES__

